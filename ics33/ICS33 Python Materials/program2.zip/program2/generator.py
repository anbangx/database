def transform(iterable,f):
    pass


def running_count(iterable,p):
    pass

        
def n_with_pad(iterable,n,pad=None):
    pass

        
def sequence(*args):
    pass


def alternate(*args):
    pass

                
def flatten(iterable):
    pass

                
                
if __name__ == '__main__':
    import driver
    driver.driver()
