from goody import type_as_str


class DimensionError(Exception):
    def __init__(self,message=None):
        Exception.__init__(self,message)

class Dimensional:
    pass

    
    
if __name__ == '__main__':
    import driver
    driver.driver()
