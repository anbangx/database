from collections import defaultdict
from goody import type_as_str

class Bag:
    pass
    
    
if __name__ == '__main__':
    import driver
    driver.driver()   
