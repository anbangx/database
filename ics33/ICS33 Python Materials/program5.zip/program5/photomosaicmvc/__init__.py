#Create the view (which creates the widgets) and run the GUI

from photomosaicmvc.view import root

root.mainloop()