from PIL import Image

from tkinter.simpledialog import askinteger

import photomosaicmvc.controller

import prompt # for use in the Photomosaic_Limited_Repeat class

class Photomosaic():
    def __init__(self,file_name,size=None):
        if size == None:
            self.image = Image.open(file_name)
        else:
            self.image = Image.open(file_name).resize(size)

    def create_lattice(self,dbsize):
        return []
   
    def make(self,db):
        photomosaicmvc.controller.the_message_textbox.add("Making photomosaic...")
        computed = Image.new("RGB",self.image.size)
        lattice = self.create_lattice(db.size)
        db.reset()
        percent = 10
        i = 0
        #loop over all the lattice points. pasting tiles in the computed photomosaic
        #(see the instructions in the lab)
        return computed


class Photomosaic_Limited_Repeat(Photomosaic):
    pass
