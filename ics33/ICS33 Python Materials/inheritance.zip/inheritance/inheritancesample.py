class B2a:
    b2acv = 'b2acv'
    bcommon = 'bcommon in B2a'
    def __init__(self):
        self.b2a = 'b2a'
    def b2amethod(self): pass

class B2(B2a):
    b2cv = 'b'
    bcommon = 'bcommon in B2'
    def __init__(self):
        B2a.__init__(self)
        self.b1 = 'b1'
    def b1method(self): pass
    def bmethod(self): pass
  
class B1:
    b1cv = 'b2cv'
    bcommon = 'bcommon in B1'
    def __init__(self):
        self.b2 = 'b2'
    def b2method(self): pass
    def bmethod(self): pass
    def override(self):   pass
  
class D(B1,B2):
    dcv = 'dcv'
    def __init__(self):
        B1.__init__(self)
        B2.__init__(self)
        self.d = 'd'
    def dmethod(self): pass
    def override(self): pass
