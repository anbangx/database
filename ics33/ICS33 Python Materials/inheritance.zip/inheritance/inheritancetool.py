from goody import type_as_str

# where_is starts looking for attribute in an_object, and if
#   necessary looks for attribute in its class hieararchy (tracing
#   where it looks of trace_classes is True)
def where_is(an_object, attribute, trace_classes = False):
    
    # generator for breadth-first traversal of inheritance hierarchy
    #   of classes, starting at derived_class
    def traverse_hierarchy(derived_class):
        to_try             = [derived_class] # starting class
        ever_put_on_to_try = {derived_class} # ditto
        
        while to_try != []:
            class_obj = to_try.pop(0)
            yield class_obj
            # augment list with all base classes of class_obj
            #   that have not already been put on to_try
            for c in class_obj.__bases__:
                if c not in ever_put_on_to_try:
                    to_try.append(c)
                    ever_put_on_to_try.add(c)
            
    # Try to locate attribute it in object itself,
    #   otherwise try in the inheritance hierarchy
    #   starting at the class it was constructed from
    if attribute in an_object.__dict__:
        return '...in instance constructed from ' + str(type(an_object)) + ' with value ' + str(an_object.__dict__[attribute])
    else:
        for c in traverse_hierarchy(type(an_object)):
            if trace_classes:
                print('Tracing inheritance hierarchy, checking',c)
            if attribute in c.__dict__:
                return '...in ' + str(c) + ' with value ' + str(c.__dict__[attribute])
        return '?'