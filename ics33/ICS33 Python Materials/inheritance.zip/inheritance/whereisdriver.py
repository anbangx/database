import prompt
from inheritancetool import where_is



#Example:
from inheritancesample import *
d = D()
d.in_object = 'in object'
print(where_is(d,'d',True))


while True:
    try:
        exec(prompt.for_string('Command'))
    except Exception as report:
        import traceback
        traceback.print_exc()
