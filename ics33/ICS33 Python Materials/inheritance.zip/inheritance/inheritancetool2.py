from goody import type_as_str

# Similar to inheritance but uses a generic breadth-first
#   network traversal.
# To use this module import from it in whereisdriver

# generator for breadth-first traversal of a network, where
#   each node is visited once; the directly_reachable function
#   takes a node as an argument and produces all the nodes
#   directly reachable  from it
def traverse_network(start,directly_reachable):
    to_try             = [start] # starting node
    ever_put_on_to_try = {start} # ditto
    
    while to_try != []:
        node = to_try.pop(0)
        yield node
        # augment list with all nodes directly reachable
        #   from node that have not already been put on to_try
        for c in directly_reachable(node):
            if c not in ever_put_on_to_try:
                to_try.append(c)
                ever_put_on_to_try.add(c)

# where_is starts looking for attribute in an_object, and if
#   necessary looks for attribute in its class hierarchy (tracing
#   where it looks of trace_classes is True)
def where_is(an_object, attribute, trace_classes = False):
    
    # Try to locate attribute it in object itself,
    #   otherwise try in the inheritance hierarchy
    #   starting at the class it was constructed from
    if attribute in an_object.__dict__:
        return '...in instance constructed from ' + str(type(an_object)) + ' with value ' + str(an_object.__dict__[attribute])
    else:
        for c in traverse_network(type(an_object), lambda x : x.__bases__):
            if trace_classes:
                print('Tracing inheritance hierarchy, checking',c)
            if attribute in c.__dict__:
                return '...in ' + str(c) + ' with value ' + str(c.__dict__[attribute])
        return '?'