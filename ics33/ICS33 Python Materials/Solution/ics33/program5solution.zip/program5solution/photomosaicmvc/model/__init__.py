#These variables are used when creating option widgets,
#  to specify all the options available in the model

metric_options_list      = ["Average_RGB()","Quad_Metric()"]
compose_options_list     = ["Quad_Metric"]
db_options_list          = ["DB_Tiles","DB_Tiles_Used","DB_Tiles_Random_Shifted","DB_Tiles_Best_Shifted"]
photomosaic_options_list = ["Photomosaic","Photomosaic_Limited_Repeat"]
filter_options_list      = ["gray_scale","intensity( (dr,dg,db) )"]